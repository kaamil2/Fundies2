

class MTLoBuddy implements ILoBuddy {
  MTLoBuddy() {}

  /*
   * Template:
   * Fields:
   * Methods:
   * directBuddyHelper -- Person -> boolean
   *
   *
   * Methods for fields:
   *
   */


  public boolean directBuddyHelper(Person that) {
    return false;
  }

  public int countCommmonBuddieshelper(Person that, ILoBuddy thisBuddies) {
    return 0;
  }

  public boolean hasExtendedBuddies(Person that, ILoBuddy partyPeople) {
    return false;
  }

  public ILoBuddy partyCountHelper(ILoBuddy partyList) {
      return partyList;
    }

    public int count() {
      return this.countHelp(0);
    }

    public int countHelp(int count) {
      return count;
    }





}
