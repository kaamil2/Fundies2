

class ConsLoBuddy implements ILoBuddy {

  Person first;
  ILoBuddy rest;

  /*
   * Template:
   * Fields:
   *
   * this.first -- Person
   * this.rest -- ILoBuddy
   * Methods:
   * directBuddyHelper -- Person -> boolean
   *
   *
   * Methods for fields:
   * this,rest.directBuddyHelper -- Person -> boolean
   *
   */

  ConsLoBuddy(Person first, ILoBuddy rest) {
    this.first = first;
    this.rest = rest;
  }

  public boolean directBuddyHelper(Person that) {
    return this.first.username.equals(that.username)
        || this.rest.directBuddyHelper(that);
  }

  public int countCommmonBuddieshelper(Person that, ILoBuddy thisBuddies) {
    if (thisBuddies.directBuddyHelper(this.first)) {
      return 1 + this.rest.countCommmonBuddieshelper(that, thisBuddies);
    } else {
      return this.rest.countCommmonBuddieshelper(that, thisBuddies);
    }
  }

  public boolean hasExtendedBuddies(Person that, ILoBuddy partyPeople) {

    if(partyPeople.directBuddyHelper(this.first)) {
      return this.rest.hasExtendedBuddies(that, partyPeople);
    } else {
      return this.rest.hasExtendedBuddies(that, new ConsLoBuddy(this.first, partyPeople))
          || this.first.hasDirectBuddy(that)
          || this.first.hasExtendedBuddy(that, new ConsLoBuddy(this.first, partyPeople));
    }

    //return this.first.hasDirectBuddy(that) || this.rest.hasExtendedBuddies(that);
  }


  // counts the number of people who will show up at the party
  public ILoBuddy partyCountHelper(ILoBuddy partyList) {

    if (partyList.directBuddyHelper(this.first)) {
      return this.rest.partyCountHelper(partyList);
    } else {
      return this.rest.partyCountHelper(this.first.getParty(partyList));
    }
  }

  public int count() {
    return this.countHelp(0);
  }

  public int countHelp(int count) {
    return this.rest.countHelp(count + 1);
  }





}
