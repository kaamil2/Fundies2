

interface ILoBuddy {


  boolean directBuddyHelper(Person that);

  int countCommmonBuddieshelper(Person that, ILoBuddy thisBuddies);

  boolean hasExtendedBuddies(Person that, ILoBuddy partyPeople);

  ILoBuddy partyCountHelper(ILoBuddy partyList);

  int count();

  int countHelp(int count);



}
