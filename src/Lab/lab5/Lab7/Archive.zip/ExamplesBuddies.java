

import tester.Tester;

// runs tests for the buddies problem
class ExamplesBuddies {

  Person ann = new Person("Ann");
  Person  bob = new Person("Bob");
  Person cole = new Person("Cole");
  Person dan = new Person("Dan");
  Person ed = new Person("Ed");
  Person fay = new Person("Fay");
  Person gabi = new Person("Gabi");
  Person hank = new Person("Hank");
  Person jan = new Person("Jan");
  Person kim = new Person("Kim");
  Person len = new Person("Len");

  Person mark = new Person("Mark");


  void initBuddies() {


    // Ann's buddies are Bob and Cole
    ann.addBuddy(bob);
    ann.addBuddy(cole);
    // Bob's buddies are Ann, Ed, and Hank
    bob.addBuddy(ann);
    bob.addBuddy(ed);
    bob.addBuddy(hank);
    // Cole's buddy is Dan
    cole.addBuddy(dan);
    // Dan's buddy is Cole
    dan.addBuddy(cole);
    // Ed's buddy is Fay
    ed.addBuddy(fay);
    // Fay's buddies are Ed and Gabi
    fay.addBuddy(ed);
    fay.addBuddy(gabi);
    // Gabi's buddies are Ed and Fay
    gabi.addBuddy(ed);
    gabi.addBuddy(fay);
    // Hank does not have any buddies
    // Jan's buddies are Kim and Len
    jan.addBuddy(kim);
    jan.addBuddy(len);
    // Kim's buddies are Jan and Len
    kim.addBuddy(jan);
    kim.addBuddy(len);
    // Len's buddies are Jan and Kim
    len.addBuddy(jan);
    len.addBuddy(kim);
    // Mark's buddies are jan and kim and ann and bob and len
    mark.addBuddy(jan);
    mark.addBuddy(kim);
    mark.addBuddy(ann);
    mark.addBuddy(bob);
    mark.addBuddy(len);





  }

/*
  boolean testDirectBuddyHelper(Tester t) {
    this.initBuddies();
    return t.checkExpect(this.ann.directBuddyHelpers(this.bob), true)
   && t.checkExpect(this.ann.directBuddyHelpers(this.dan), false)
    && t.checkExpect(this.ann.directBuddyHelpers(this.ann), false)
   && t.checkExpect(this.ed.directBuddyHelpers(this.fay), true)
   && t.checkExpect(this.hank.directBuddyHelpers(this.jan), false)
   && t.checkExpect(this.jan.directBuddyHelpers(this.len), true);
  }

  boolean testHasDirectBuddy(Tester t) {
    this.initBuddies();
    return t.checkExpect(this.ann.hasDirectBuddy(this.bob), true)
   && t.checkExpect(this.ann.hasDirectBuddy(this.dan), false)
    && t.checkExpect(this.ann.hasDirectBuddy(this.ann), false)
    && t.checkExpect(this.ann.hasDirectBuddy(this.fay), false)
    && t.checkExpect(this.ann.hasDirectBuddy(this.jan), false)
   && t.checkExpect(this.ann.hasDirectBuddy(this.len), false)
    &&  t.checkExpect(this.jan.hasDirectBuddy(this.len), true)
   &&  t.checkExpect(this.jan.hasDirectBuddy(this.ann), false)
    && t.checkExpect(this.jan.hasDirectBuddy(this.jan), false)
   &&  t.checkExpect(this.jan.hasDirectBuddy(this.fay), false)
   &&  t.checkExpect(this.jan.hasDirectBuddy(this.kim), true)
   &&  t.checkExpect(this.jan.hasDirectBuddy(this.ed), false)
   &&  t.checkExpect(this.hank.hasDirectBuddy(this.gabi), false);
  }


  // tests for the method countCommonBuddies
  boolean testCountCommonBuddies(Tester t) {
    this.initBuddies();
    return t.checkExpect(this.ann.countCommonBuddies(this.bob), 0)
    && t.checkExpect(this.bob.countCommonBuddies(this.fay), 1)
   &&  t.checkExpect(this.jan.countCommonBuddies(this.len), 1)
    && t.checkExpect(this.hank.countCommonBuddies(this.kim), 0)
    && t.checkExpect(this.ann.countCommonBuddies(this.dan), 1)
   &&  t.checkExpect(this.ann.countCommonBuddies(this.fay), 0)
    && t.checkExpect(this.mark.countCommonBuddies(this.jan), 2);
  }

  // tests for the method hasExtendedBuddy
  boolean testHasExtendedBuddy(Tester t) {
    this.initBuddies();
    return t.checkExpect(this.ann.hasExtendedBuddy(this.bob), true)
        && t.checkExpect(this.ann.hasExtendedBuddy(this.dan), true)
        && t.checkExpect(this.ann.hasExtendedBuddy(this.fay), true)
        && t.checkExpect(this.bob.hasExtendedBuddy(this.jan), false)
        && t.checkExpect(this.hank.hasExtendedBuddy(this.len), false)
        && t.checkExpect(this.jan.hasExtendedBuddy(this.len), true)
        && t.checkExpect(this.jan.hasExtendedBuddy(this.ann), false)
        && t.checkExpect(this.gabi.hasExtendedBuddy(this.hank), false);

  }
  */



  void testHasDirectBuddy(Tester t) {
    this.initBuddies();
    t.checkExpect(this.ann.hasDirectBuddy(this.bob), true);
    t.checkExpect(this.ann.hasDirectBuddy(this.dan), false);
    t.checkExpect(this.ann.hasDirectBuddy(this.ann), false);
    t.checkExpect(this.ann.hasDirectBuddy(this.fay), false);
    t.checkExpect(this.ann.hasDirectBuddy(this.jan), false);
    t.checkExpect(this.ann.hasDirectBuddy(this.len), false);
    t.checkExpect(this.jan.hasDirectBuddy(this.len), true);
    t.checkExpect(this.jan.hasDirectBuddy(this.ann), false);
    t.checkExpect(this.jan.hasDirectBuddy(this.jan), false);
    t.checkExpect(this.jan.hasDirectBuddy(this.fay), false);
    t.checkExpect(this.jan.hasDirectBuddy(this.kim), true);
    t.checkExpect(this.jan.hasDirectBuddy(this.ed), false);
    t.checkExpect(this.hank.hasDirectBuddy(this.gabi), false);
  }


  // tests for the method countCommonBuddies
  void testCountCommonBuddies(Tester t) {
    this.initBuddies();
    t.checkExpect(this.ann.countCommonBuddies(this.bob), 0);
    t.checkExpect(this.bob.countCommonBuddies(this.fay), 1);
    t.checkExpect(this.jan.countCommonBuddies(this.len), 1);
    t.checkExpect(this.hank.countCommonBuddies(this.kim), 0);
    t.checkExpect(this.ann.countCommonBuddies(this.dan), 1);
    t.checkExpect(this.ann.countCommonBuddies(this.fay), 0);
    t.checkExpect(this.mark.countCommonBuddies(this.jan), 2);
  }

  // tests for the method hasExtendedBuddy
  void testHasExtendedBuddy(Tester t) {
    this.initBuddies();
    t.checkExpect(this.ann.hasExtendedBuddy(this.bob), true);
    t.checkExpect(this.ann.hasExtendedBuddy(this.dan), true);
    t.checkExpect(this.ann.hasExtendedBuddy(this.fay), true);
    t.checkExpect(this.bob.hasExtendedBuddy(this.jan), false);
    t.checkExpect(this.hank.hasExtendedBuddy(this.len), false);
    t.checkExpect(this.jan.hasExtendedBuddy(this.len), true);
    t.checkExpect(this.jan.hasExtendedBuddy(this.ann), false);
    t.checkExpect(this.gabi.hasExtendedBuddy(this.hank), false);
  }



  // tests for the method partyCount
  void testPartyCount(Tester t) {
    this.initBuddies();
    t.checkExpect(this.ann.partyCount(), 8);
    t.checkExpect(this.bob.partyCount(), 8);
    t.checkExpect(this.hank.partyCount(), 1);
    t.checkExpect(this.dan.partyCount(), 2);
    t.checkExpect(this.jan.partyCount(), 3);
    t.checkExpect(this.len.partyCount(),3);
    t.checkExpect(this.hank.partyCount(), 1);
  }






  void testDirectBuddyHelper(Tester t) {
    this.initBuddies();
    t.checkExpect(this.ann.directBuddyHelpers(this.bob), true);
    t.checkExpect(this.ann.directBuddyHelpers(this.dan), false);
    t.checkExpect(this.ann.directBuddyHelpers(this.ann), false);
    t.checkExpect(this.ed.directBuddyHelpers(this.fay), true);
    t.checkExpect(this.hank.directBuddyHelpers(this.jan), false);
    t.checkExpect(this.jan.directBuddyHelpers(this.len), true);
  }



  /*
  void testAddBuddy(Tester t) {
    this.initBuddies();
    t.checkExpect(this.ann.addBuddy(this.dan),
        new ConsLoBuddy(this.dan,
            new ConsLoBuddy(this.cole, new ConsLoBuddy(this.bob, new MTLoBuddy()))));

  }
*/





}
